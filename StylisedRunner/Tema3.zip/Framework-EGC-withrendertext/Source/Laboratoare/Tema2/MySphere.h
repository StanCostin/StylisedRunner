#pragma once

typedef struct Sphere {
	float x;
	float y;
	float z;
	float radius;
}stuctSphere;