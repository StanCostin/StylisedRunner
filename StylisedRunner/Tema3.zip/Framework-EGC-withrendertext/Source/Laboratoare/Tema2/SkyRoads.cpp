#include"SkyRoads.h"

#include <Core/Engine.h>

SkyRoads::SkyRoads()
{
}

SkyRoads::~SkyRoads()
{
}

void SkyRoads::Init()
{
	srand(time(0));
	renderCameraTarget = false;

	camera = new MyCamera::CameraImplement();
	camera->Set(glm::vec3(0, 1.0f, 2.f), glm::vec3(0, 1, 0), glm::vec3(0, 1, 0));

	speedPlatform = 0;
	platforms = 0;
	isFalling = false;
	combustion = 10000;
	stateCombustionGreen = 0;
	stateCombustionYellow = 0;
	saveDTS = 0;
	state = 0;
	timer = 0;
	saveSpherepos = 0;
	jmpLock = 0;
	timeToChange = 0;

	{
		Mesh* mesh = new Mesh("box");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "box.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Mesh* mesh = new Mesh("CombustionMeter");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "screen_quad.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Mesh* mesh = new Mesh("CombustionScreen");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "screen_quad.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Mesh* mesh = new Mesh("sphere");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "sphere.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	projectionMatrix = glm::perspective(RADIANS(60), window->props.aspectRatio, 0.01f, 200.0f);


	v = new int[3];

	for (int i = 0; i < 3; i++)
	{
		v[i] = rand()%3;

	}

	if (v[0] == 0)
	{
		for (int i = 0; i < 25; i++)
		{
			for (int j = 0; j < 5; j++)
			{
				matGame[i][j] = saveMatGame[i][j];
			}
		}
	}
	else if (v[0] == 1)
	{
		for (int l = 0; l < 25; l++)
		{
			for (int c = 0; c < 5; c++)
			{
				matGame[l][c] = saveMatGame1[l][c];
			}
		}
	}
	else if (v[0] == 2)
	{
		for (int n = 0; n < 25; n++)
		{
			for (int m = 0; m < 5; m++)
			{
				matGame[n][m] = saveMatGame2[n][m];
			}
		}
	}

}

void SkyRoads::FrameStart()
{
	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(0, 0, 0, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}

void SkyRoads::Update(float deltaTimeSeconds)
{
	moveSphere(xSphere, ySphere);

	speedPlatform += 1 * deltaTimeSeconds;

	timeToChange = deltaTimeSeconds;

	saveDTS = deltaTimeSeconds;

	if (jmpLock == 1 && ySphere < 2)
	{
		ySphere += 3 * deltaTimeSeconds;
	}
	else if (jmpLock == 1 && ySphere >= 2)
	{
		jmpLock = 2;
		ySphere -= 3 * deltaTimeSeconds;
	}
	else if (jmpLock == 2)
	{
		if (ySphere == 0)
		{
			jmpLock = 0;
		}
		else
		{
			ySphere -= 3 * deltaTimeSeconds;
		}
	}

	combustion-= 100*deltaTimeSeconds;

	//cout << "Final combostion:" << combustion << endl;

	if (stateCombustionGreen == 1)
	{
		rewardCombostion = 100;
		combustion += rewardCombostion;
		cout << "You have touched the green platform! You win :" << rewardCombostion << " combustion!" << endl;
		stateCombustionGreen = -1;
	}

	if (stateCombustionYellow == 1)
	{
		drainCombustion = 500;
		combustion -= drainCombustion;
		cout << "You have touched the yellow platform! You lose :" << drainCombustion << " combustion!" << endl;
		stateCombustionYellow = -1;
	}

	if (combustion <= 0)
	{
		cout << "You are out of fuel!" << endl;
		cout << "Final combustion:" << combustion << endl;
		exit(0);
	}

	if (state == 1)
	{
		timer -= 2 * deltaTimeSeconds;
		platforms += 10 * deltaTimeSeconds;
		if (timer <= 0)
			state = 0;
	}

	if (xSphere < -3)
	{
		saveSpherepos = 0;
	}

	if (xSphere >= -3 && xSphere < -1)
	{
		saveSpherepos = 1;
	}

	if (xSphere >= -1 && xSphere < 1)
	{
		saveSpherepos = 2;
	}

	if (xSphere >= 1 && xSphere < 3)
	{
		saveSpherepos = 3;
	}

	if (xSphere >= 3)
	{
		saveSpherepos = 4;
	}


	for (int k = 0; k < 3; k++)
	{
		if (v[k] == 0)
		{
			for (int i = 0; i < 25; i++)
			{
				for (int j = 0; j < 5; j++)
				{
					glm::mat4 modelMatrix = glm::mat4(1);
					modelMatrix = glm::translate(modelMatrix, glm::vec3(j - 2, 0.10, -26 * k - i + platforms + speedPlatform));
					modelMatrix *= MyTransformer3D::Scale(1, 0.2, 1);

					if (matGame[i][j] == 1)
					{
						RenderMesh(meshes["box"], shaders["White"], modelMatrix);
					}
					else if (matGame[i][j] == 2)
					{
						RenderMesh(meshes["box"], shaders["Green"], modelMatrix);
					}
					else if (matGame[i][j] == 3)
					{
						RenderMesh(meshes["box"], shaders["Yellow"], modelMatrix);
					}
					else if (matGame[i][j] == 4)
					{
						RenderMesh(meshes["box"], shaders["Red"], modelMatrix);
					}
					else if (matGame[i][j] == 5)
					{
						RenderMesh(meshes["box"], shaders["Orange"], modelMatrix);
					}
					else if (matGame[i][j] == 6)
					{
						RenderMesh(meshes["box"], shaders["Mangenta"], modelMatrix);
					}
				}
				if (i == (int)(ceil(platforms + speedPlatform)))
				{
					if ((matGame[i][saveSpherepos] == 0) && (ySphere == 0))
					{
						isFalling = true;
					}
					else if (matGame[i][saveSpherepos] == 1 && (ySphere == 0))
					{
						stateCombustionGreen = 0;
						stateCombustionYellow = 0;
						
						cout << "Alb" << endl;
					}
					else if (matGame[i][saveSpherepos] == 2 && (ySphere == 0))
					{
						cout << "Verde!" << endl;
						if (stateCombustionGreen != -1)
						{
							stateCombustionGreen = 1;
						}
						stateCombustionYellow = 0;
					}
					else if (matGame[i][saveSpherepos] == 3 && (ySphere == 0))
					{
						stateCombustionGreen = 0;
						if (stateCombustionYellow != -1)
						{
							stateCombustionYellow = 1;
						}
					

					}
					else if (matGame[i][saveSpherepos] == 4 && (ySphere == 0))
					{
						cout << "You have touched the red platform! Game over!" << endl;
						exit(0);
					}
					else if (matGame[i][saveSpherepos] == 5 && (ySphere == 0))
					{
						stateCombustionGreen = 0;
						stateCombustionYellow = 0;
						state = 1;
						cout << "Your keybords W and S for movement platform are blocked for 5 seconds!" << endl;
						timer = 5;


					}

					if (matGame[i][saveSpherepos] != 0 && (ySphere == 0))
					{
						matGame[i][saveSpherepos] = 6;
					}

				}
			}
		}
		else if (v[k] == 1)
		{
			for (int l = 0; l < 25; l++)
			{
				for (int c = 0; c < 5; c++)
				{
					glm::mat4 modelMatrix1 = glm::mat4(1);
					modelMatrix1 = glm::translate(modelMatrix1, glm::vec3(2 - c, 0.10, -26 * k - l + platforms + speedPlatform));
					modelMatrix1 *= MyTransformer3D::Scale(1, 0.2, 1);

					if (matGame[l][c] == 1)
					{
						RenderMesh(meshes["box"], shaders["White"], modelMatrix1);
					}
					else if (matGame[l][c] == 2)
					{
						RenderMesh(meshes["box"], shaders["Green"], modelMatrix1);
					}
					else if (matGame[l][c] == 3)
					{
						RenderMesh(meshes["box"], shaders["Yellow"], modelMatrix1);
					}
					else if (matGame[l][c] == 5)
					{
						RenderMesh(meshes["box"], shaders["Orange"], modelMatrix1);
					}
					else if (matGame[l][c] == 6)
					{
						RenderMesh(meshes["box"], shaders["Mangenta"], modelMatrix1);
					}

				}
				if (l == (int)(ceil(platforms + speedPlatform)))
				{
					if ((matGame[l][saveSpherepos] == 0) && (ySphere == 0))
					{
						isFalling = true;
					}
					else if (matGame[l][saveSpherepos] == 1 && (ySphere == 0))
					{
						stateCombustionGreen = 0;
						stateCombustionYellow = 0;
						cout << "Alb" << endl;
					}
					else if (matGame[l][saveSpherepos] == 2 && (ySphere == 0))
					{
						cout << "Verde!" << endl;
						if (stateCombustionGreen != -1)
						{
							stateCombustionGreen = 1;
						}

						stateCombustionYellow = 0;
					}
					else if (matGame[l][saveSpherepos] == 3 && (ySphere == 0))
					{
						stateCombustionGreen = 0;
						if (stateCombustionYellow != -1)
						{
							stateCombustionYellow = 1;
						}
					}
					else if (matGame[l][saveSpherepos] == 5 && (ySphere == 0))
					{
						stateCombustionGreen = 0;
						stateCombustionYellow = 0;
						state = 1;
						cout << "Your keybords W and S for movement platform are blocked for 5 seconds!" << endl;
						timer = 5;
					}

					if (matGame[l][saveSpherepos] != 0 && (ySphere == 0))
					{
						matGame[l][saveSpherepos] = 6;
					}
				}
			}
		}
		else if (v[k] == 2)
		{
			for (int n = 0; n < 25; n++)
			{
				for (int m = 0; m < 5; m++)
				{
					glm::mat4 modelMatrix2 = glm::mat4(1);
					modelMatrix2 = glm::translate(modelMatrix2, glm::vec3(m - 2, 0.10, -26 * k - n + platforms + speedPlatform));
					modelMatrix2 *= MyTransformer3D::Scale(1, 0.2, 1);

					if (matGame[n][m] == 1)
					{
						RenderMesh(meshes["box"], shaders["White"], modelMatrix2);
					}
					else if (matGame[n][m] == 2)
					{
						RenderMesh(meshes["box"], shaders["Green"], modelMatrix2);
					}
					else if (matGame[n][m] == 3)
					{
						RenderMesh(meshes["box"], shaders["Yellow"], modelMatrix2);
					}
					else if (matGame[n][m] == 4)
					{
						RenderMesh(meshes["box"], shaders["Red"], modelMatrix2);
					}
					else if (matGame[n][m] == 5)
					{
						RenderMesh(meshes["box"], shaders["Orange"], modelMatrix2);
					}
					else if (matGame[n][m] == 6)
					{
						RenderMesh(meshes["box"], shaders["Mangenta"], modelMatrix2);
					}
				}
				if (n == (int)(ceil(platforms + speedPlatform)))
				{
					if ((matGame[n][saveSpherepos] == 0) && (ySphere == 0))
					{
						isFalling = true;
					}
					else if (matGame[n][saveSpherepos] == 1 && (ySphere == 0))
					{
						stateCombustionGreen = 0;
						stateCombustionYellow = 0;
						cout << "Alb" << endl;
					}
					else if (matGame[n][saveSpherepos] == 2 && (ySphere == 0))
					{
						cout << "Verde!" << endl;
						if (stateCombustionGreen != -1)
						{
							stateCombustionGreen = 1;
						}

						stateCombustionYellow = 0;
					}
					else if (matGame[n][saveSpherepos] == 3 && (ySphere == 0))
					{
						stateCombustionGreen = 0;
						if (stateCombustionYellow != -1)
						{
							stateCombustionYellow = 1;
						}
					}
					else if (matGame[n][saveSpherepos] == 4 && (ySphere == 0))
					{
						cout << "You have touched the red platform! Game over!" << endl;
						exit(0);
					}
					else if (matGame[n][saveSpherepos] == 5 && (ySphere == 0))
					{
						stateCombustionGreen = 0;
						stateCombustionYellow = 0;
						state = 1;
						cout << "Your keybords W and S for movement platform are blocked for 5 seconds!" << endl;
						timer = 5;

					}

					if (matGame[n][saveSpherepos] != 0 && (ySphere == 0))
					{
						matGame[n][saveSpherepos] = 6;
					}
				}

			}
		}
	}

	if (speedPlatform + platforms >= 26)
	{
		speedPlatform = 0;
		platforms = 0;
		shiftLeft();

		if (v[0] == 0)
		{
			for (int i = 0; i < 25; i++)
			{
				for (int j = 0; j < 5; j++)
				{
					matGame[i][j] = saveMatGame[i][j];
				}
			}
		}
		else if (v[0] == 1)
		{
			for (int l = 0; l < 25; l++)
			{
				for (int c = 0; c < 5; c++)
				{
					matGame[l][c] = saveMatGame1[l][c];
				}
			}
		}
		else if (v[0] == 2)
		{
			for (int n = 0; n < 25; n++)
			{
				for (int m = 0; m < 5; m++)
				{
					matGame[n][m] = saveMatGame2[n][m];
				}
			}
		}
	}

	if (combustion >= 10000)
		combustion = 10000;

	glm::mat4 ModelMatrix = glm::mat4(1);
	ModelMatrix = glm::translate(ModelMatrix, glm::vec3(0.4, 0.8, 0));
	ModelMatrix = glm::scale(ModelMatrix, glm::vec3(0.20, 0.1, 0.1));
	ModelMatrix = glm::translate(ModelMatrix, glm::vec3(combustion / 10000, 0, 0));
	ModelMatrix = glm::scale(ModelMatrix, glm::vec3(combustion / 10000, 1, 1));
	CombustionMesh(meshes["CombustionMeter"], shaders["Combustion"], ModelMatrix, glm::vec3(1,0,1));

	glm::mat4 ModelMatrix1  = glm::mat4(1);
	ModelMatrix1 = glm::translate(ModelMatrix1, glm::vec3(0.6, 0.8, 0));
	ModelMatrix1 = glm::scale(ModelMatrix1, glm::vec3(0.21, 0.11, 0.11));
	CombustionMesh(meshes["CombustionScreen"], shaders["Combustion"], ModelMatrix1, glm::vec3(1, 1, 1));

}

void SkyRoads::FrameEnd()
{
	
}

void SkyRoads::RenderMesh(Mesh * mesh, Shader * shader, const glm::mat4 & modelMatrix)
{
	if (!mesh || !shader || !shader->program)
		return;

	shader->Use();
	glUniformMatrix4fv(shader->loc_view_matrix, 1, GL_FALSE, glm::value_ptr(camera->GetViewMatrix()));
	glUniformMatrix4fv(shader->loc_projection_matrix, 1, GL_FALSE, glm::value_ptr(projectionMatrix));
	glUniformMatrix4fv(shader->loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

	mesh->Render();
}


void SkyRoads::RenderFromSphere(Mesh * mesh, Shader * shader, const glm::mat4 & modelMatrix, glm::vec3 color)
{
	if (!mesh || !shader || !shader->program)
		return;
	shader->Use();
	int pos = glGetUniformLocation(shader->program, "color");
	glUniform3fv(pos, 1, glm::value_ptr(color));

	int pos2 = glGetUniformLocation(shader->program, "changeTime");
	glUniform1f(pos2, timeToChange);

	glUniformMatrix4fv(shader->loc_view_matrix, 1, GL_FALSE, glm::value_ptr(camera->GetViewMatrix()));
	glUniformMatrix4fv(shader->loc_projection_matrix, 1, GL_FALSE, glm::value_ptr(projectionMatrix));
	glUniformMatrix4fv(shader->loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

	mesh->Render();
}


void SkyRoads::CombustionMesh(Mesh * mesh, Shader * shader, const glm::mat4 & modelMatrix, glm::vec3 color)
{
	if (!mesh || !shader || !shader->program)
		return;

	shader->Use();

	int pos = glGetUniformLocation(shader->program, "color");
	glUniform3fv(pos, 1, glm::value_ptr(color));

	glUniformMatrix4fv(shader->loc_view_matrix, 1, GL_FALSE, glm::value_ptr(camera->GetViewMatrix()));
	glUniformMatrix4fv(shader->loc_projection_matrix, 1, GL_FALSE, glm::value_ptr(projectionMatrix));
	glUniformMatrix4fv(shader->loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

	mesh->Render();
}

void SkyRoads::OnInputUpdate(float deltaTime, int mods)
{
	if ((window->KeyHold(GLFW_KEY_D)) && (!window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT)))
	{
		xSphere += 2 * deltaTime;
	}

	if (window->KeyHold(GLFW_KEY_A) && (!window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT)))
	{
		xSphere -= 2 * deltaTime;

	}

	if (window->KeyHold(GLFW_KEY_W) && (!window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT)) && state == 0 && isFalling == false)
	{
		platforms += 2 * deltaTime;
		combustion -= 10 * deltaTime;
	}

	if (window->KeyHold(GLFW_KEY_S) && (!window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT)) && state == 0 && isFalling == false)
	{
		platforms += 0.5 * deltaTime;
		combustion -= 10 * deltaTime;
	}


	if (window->KeyHold(GLFW_KEY_SPACE) && jmpLock == 0)
	{
		jmpLock = 1;
	}

}

void SkyRoads::OnKeyPress(int key, int mods)
{
	if (key == GLFW_KEY_C)
	{
		camera->stateCamera();
	}
}

void SkyRoads::OnKeyRelease(int key, int mods)
{

}

void SkyRoads::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event

	
}

void SkyRoads::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void SkyRoads::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void SkyRoads::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void SkyRoads::OnWindowResize(int width, int height)
{
}

void SkyRoads::moveSphere(float x, float y)
{
	if (y > 3)
	{
		ySphere = 3;
	}

	if (isFalling == true)
	{
		ySphere -= 3 * saveDTS;

		if (isFalling == true && ySphere >= 0)
		{
			ySphere -= 3 * saveDTS;
		}

		if (isFalling == true && ySphere <= 0)
		{
			ySphere -= 3 * saveDTS;
		}

		if (ySphere < -3)
		{
			cout << "You have fallen from the platforms! Game over!" << endl;
			exit(0);
		}
	}


	if (isFalling == false)
	{
		if (y <= 0)
		{
			ySphere = 0;
		}
	}



	if (x < -4)
	{
		xSphere = -4;
	}

	if (x >= 4)
	{
		xSphere = 4;
	}

	glm::mat4 modelMatrix = glm::mat4(1);
	modelMatrix = glm::translate(modelMatrix, glm::vec3(0, 0.45, 0));
	modelMatrix = glm::scale(modelMatrix, glm::vec3(.5f));
	modelMatrix *= MyTransformer3D::Translate(x, y, 0);

	if (timer > 0)
	{
		RenderFromSphere(meshes["sphere"], shaders["FormSphere"], modelMatrix, glm::vec3(1, 0.5, 0));
	}
	else
	{
		RenderMesh(meshes["sphere"], shaders["VertexNormal"], modelMatrix);
	}

}

void SkyRoads::shiftLeft()
{
	for (int i = 0; i < 2; i++)
	{
		v[i] = v[i + 1];
	}

	v[2] = rand() % 3;

}