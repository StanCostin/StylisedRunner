#pragma once
#include<iostream>
#include<Component/SimpleScene.h>
#include"MyCamera.h"
#include"MyTransformer3D.h"
#include<vector>
#include<string>
#include<time.h>
#include<Core/Engine.h>
using namespace std;



class SkyRoads : public SimpleScene{
	
private:
	
	void FrameStart() override;
	void Update(float deltaTimeSeconds) override;
	void FrameEnd() override;

	void RenderMesh(Mesh * mesh, Shader * shader, const glm::mat4 & modelMatrix);

	void RenderFromSphere(Mesh * mesh, Shader * shader, const glm::mat4 & modelMatrix, glm::vec3 color);

	void CombustionMesh(Mesh * mesh, Shader * shader, const glm::mat4 & modelMatrix, glm::vec3 color);

	void OnInputUpdate(float deltaTime, int mods) override;
	void OnKeyPress(int key, int mods) override;
	void OnKeyRelease(int key, int mods) override;
	void OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) override;
	void OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) override;
	void OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) override;
	void OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) override;
	void OnWindowResize(int width, int height) override;
	void moveSphere(float x, float y);

	void shiftLeft();
	
public:	
	
	void Init() override;
	SkyRoads();
	~SkyRoads();


protected:
	MyCamera::CameraImplement *camera;
	glm::mat4 projectionMatrix;
	bool renderCameraTarget;
	float platforms;
	float speedPlatform;
	
	float xSphere;
	float ySphere;

	bool isFalling;


	int *v;

	float saveDTS;

	int matGame[25][5] = {
		{1, 0, 1, 0, 1},
		{1, 0, 1, 0, 0},
		{1, 0, 1, 0, 1},
		{1, 0, 0, 0, 0},
		{0, 0, 1, 0, 2},
		{2, 0, 1, 0, 0},
		{0, 0, 1, 0, 1},
		{1, 0, 1, 0, 2},
		{0, 0, 0, 0, 0},
		{1, 1, 2, 1, 1},
		{1, 1, 1, 0, 1},
		{1, 0, 3, 0, 1},
		{1, 0, 1, 3, 5},
		{1, 4, 4, 0, 5},
		{0, 2, 1, 0, 1},
		{1, 2, 1, 1, 1},
		{3, 0, 2, 0, 2},
		{1, 0, 1, 0, 0},
		{1, 0, 1, 0, 1},
		{1, 0, 5, 0, 0},
		{1, 0, 1, 0, 1},
		{1, 0, 1, 0, 0},
		{1, 0, 3, 0, 1},
		{4, 0, 2, 0, 4},
		{4, 0, 2, 0, 4},
	};

	int saveMatGame[25][5] = {
		{1, 0, 1, 0, 1},
		{1, 0, 1, 0, 0},
		{1, 0, 1, 0, 1},
		{1, 0, 0, 0, 0},
		{0, 0, 1, 0, 2},
		{2, 0, 1, 0, 0},
		{0, 0, 1, 0, 1},
		{1, 0, 1, 0, 2},
		{0, 0, 0, 0, 0},
		{1, 1, 2, 1, 1},
		{1, 1, 1, 0, 1},
		{1, 0, 3, 0, 1},
		{1, 0, 1, 3, 5},
		{1, 4, 4, 0, 5},
		{0, 2, 1, 0, 1},
		{1, 2, 1, 1, 1},
		{3, 0, 2, 0, 2},
		{1, 0, 1, 0, 0},
		{1, 0, 1, 0, 1},
		{1, 0, 5, 0, 0},
		{1, 0, 1, 0, 1},
		{1, 0, 1, 0, 0},
		{1, 0, 3, 0, 1},
		{4, 0, 2, 0, 4},
		{4, 0, 2, 0, 4},
	};

	int saveMatGame1[25][5] = {
		{0, 0, 1, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 2, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 2, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 2, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 3, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 3, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 5, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 5, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 0, 0, 0},
		{0, 0, 1, 0, 0},
	};


	int saveMatGame2[25][5] = {
		{0, 1, 1, 1, 0},
		{0, 1, 1, 1, 0},
		{0, 1, 1, 1, 0},
		{0, 2, 0, 1, 0},
		{0, 1, 0, 1, 0},
		{0, 1, 2, 1, 0},
		{0, 2, 5, 4, 0},
		{0, 1, 2, 1, 0},
		{0, 1, 0, 1, 0},
		{0, 2, 0, 4, 0},
		{0, 1, 2, 1, 0},
		{0, 1, 2, 1, 0},
		{0, 3, 0, 3, 0},
		{0, 1, 0, 1, 0},
		{0, 1, 1, 1, 0},
		{0, 3, 4, 3, 0},
		{0, 1, 1, 1, 0},
		{0, 1, 0, 1, 0},
		{0, 5, 0, 5, 0},
		{0, 1, 0, 1, 0},
		{0, 1, 0, 1, 0},
		{0, 4, 0, 4, 0},
		{0, 1, 1, 1, 0},
		{0, 1, 4, 1, 0},
		{0, 1, 1, 1, 0},
	};

	int saveSpherepos;

	float combustion;
	float rewardCombostion;
	float drainCombustion;

	int stateCombustionGreen;
	int stateCombustionYellow;

	float timeToJump;

	int jmpLock;

	int state;

	float timer;
	float timeToChange;

};