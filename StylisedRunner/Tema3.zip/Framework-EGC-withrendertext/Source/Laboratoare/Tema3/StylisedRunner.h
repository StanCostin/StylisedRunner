#pragma once
#include<iostream>
#include<Component/SimpleScene.h>
#include<TextRenderer/TextRenderer.h>
#include<vector>
#include"MyCameraT3.h"
#include"MyTransformer3DT3.h"
#include<string>
#include<time.h>
#include<Core/Engine.h>
using namespace std;

class StylisedRunner : public SimpleScene{

private:

	void FrameStart() override;
	void Update(float deltaTimeSeconds) override;

	void drawHud();

	void FrameEnd() override;

	void RenderMeshTexture(Mesh *mesh, Shader *shader, const glm::mat4 & modelMatrix, Texture2D* texture1);

	void RenderMesh(Mesh * mesh, Shader * shader, const glm::mat4 & modelMatrix);

	void RenderFromSphere(Mesh * mesh, Shader * shader, const glm::mat4 & modelMatrix, glm::vec3 color);

	void CombustionMesh(Mesh * mesh, Shader * shader, const glm::mat4 & modelMatrix, glm::vec3 color);

	void OnInputUpdate(float deltaTime, int mods) override;
	void OnKeyPress(int key, int mods) override;
	void OnKeyRelease(int key, int mods) override;
	void OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) override;
	void OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) override;
	void OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) override;
	void OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) override;
	void OnWindowResize(int width, int height) override;
	void moveSphere(float x, float y);

	void shiftLeft();

public:

	void Init() override;
	StylisedRunner();
	~StylisedRunner();


protected:
	MyCameraT3::CameraImplement *camera;
	glm::mat4 projectionMatrix;
	bool renderCameraTarget;
	float platforms;
	float speedPlatform;
	float heightPlatform1;
	float rotateBall;


	float xSphere;
	float ySphere;

	bool isFalling;

	std::unordered_map<std::string, Texture2D*> mapTextures;

	TextRenderer  *Text;
	int score;
	int stateScore;
	int changeOX;
	int changeOY;
	int changeOZ;
	float animeColectable;
	int isColectable;
	int isDangerCombustion;
	float lowCombustion;
	float rewardCombustionColectable;


	int *v;

	float saveDTS;

	int matGame[25][5] = {
		{1, 0, 1, 0, 1},
		{1, 0, 1, 0, 0},
		{1, 0, 7, 0, 1},
		{1, 0, 1, 0, 0},
		{0, 0, 8, 0, 2},
		{2, 0, 1, 0, 0},
		{0, 0, 1, 0, 1},
		{1, 0, 1, 0, 2},
		{0, 0, 0, 0, 0},
		{1, 1, 2, 1, 1},
		{1, 1, 1, 0, 1},
		{1, 0, 3, 0, 1},
		{1, 0, 1, 3, 5},
		{1, 4, 4, 0, 5},
		{0, 2, 1, 0, 1},
		{1, 2, 1, 1, 1},
		{3, 0, 2, 0, 2},
		{1, 0, 1, 0, 0},
		{1, 0, 1, 0, 1},
		{1, 0, 6, 0, 0},
		{1, 0, 1, 0, 1},
		{1, 0, 1, 0, 0},
		{1, 0, 3, 0, 1},
		{4, 0, 2, 0, 4},
		{4, 0, 2, 0, 4},
	};

	int saveMatGame[25][5] = {
		{1, 0, 1, 0, 1},
		{1, 0, 1, 0, 0},
		{1, 0, 7, 0, 1},
		{1, 0, 1, 0, 0},
		{0, 0, 8, 0, 2},
		{2, 0, 1, 0, 0},
		{0, 0, 1, 0, 1},
		{1, 0, 1, 0, 2},
		{0, 0, 0, 0, 0},
		{1, 1, 2, 1, 1},
		{1, 1, 1, 0, 1},
		{1, 0, 3, 0, 1},
		{1, 0, 1, 3, 5},
		{1, 4, 4, 0, 5},
		{0, 2, 1, 0, 1},
		{1, 2, 1, 1, 1},
		{3, 0, 2, 0, 2},
		{1, 0, 1, 0, 0},
		{1, 0, 1, 0, 1},
		{1, 0, 6, 0, 0},
		{1, 0, 1, 0, 1},
		{1, 0, 1, 0, 0},
		{1, 0, 3, 0, 1},
		{4, 0, 2, 0, 4},
		{4, 0, 2, 0, 4},
	};

	int saveMatGame1[25][5] = {
		{0, 0, 1, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 7, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 8, 0, 0},
		{0, 0, 2, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 2, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 3, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 3, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 5, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 6, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 1, 0, 0},
		{0, 0, 0, 0, 0},
		{0, 0, 1, 0, 0},
	};


	int saveMatGame2[25][5] = {
		{0, 1, 1, 1, 0},
		{0, 1, 1, 1, 0},
		{0, 1, 7, 1, 0},
		{0, 2, 1, 1, 0},
		{0, 1, 8, 1, 0},
		{0, 1, 2, 1, 0},
		{0, 2, 5, 4, 0},
		{0, 1, 2, 1, 0},
		{0, 1, 0, 1, 0},
		{0, 2, 0, 4, 0},
		{0, 1, 2, 1, 0},
		{0, 1, 2, 1, 0},
		{0, 3, 0, 3, 0},
		{0, 1, 0, 1, 0},
		{0, 1, 1, 1, 0},
		{0, 3, 4, 3, 0},
		{0, 1, 1, 1, 0},
		{0, 1, 0, 1, 0},
		{0, 5, 0, 5, 0},
		{0, 1, 0, 1, 0},
		{0, 1, 0, 1, 0},
		{0, 4, 0, 4, 0},
		{0, 1, 1, 1, 0},
		{0, 1, 4, 1, 0},
		{0, 1, 1, 1, 0},
	};

	int saveSpherepos;

	float combustion;
	float rewardCombostion;
	float drainCombustion;

	int stateCombustionGreen;
	int stateCombustionYellow;
	int stateRewardCombustion;

	float timeToJump;

	int jmpLock;

	int state;

	float timer;
	float timeToChange;

};