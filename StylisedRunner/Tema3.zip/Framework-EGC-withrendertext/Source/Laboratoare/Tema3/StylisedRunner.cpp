#include "StylisedRunner.h"

StylisedRunner::StylisedRunner()
{

}

void StylisedRunner::Init()
{
	srand(time(0));
	renderCameraTarget = false;

	camera = new MyCameraT3::CameraImplement();
	camera->Set(glm::vec3(0, 1.0f, 2.f), glm::vec3(0, 1, 0), glm::vec3(0, 1, 0));

	speedPlatform = 0;
	platforms = 0;
	isFalling = false;
	combustion = 100000;
	heightPlatform1 = 0.7;
	stateCombustionGreen = 0;
	stateCombustionYellow = 0;
	stateRewardCombustion = 0;
	rewardCombustionColectable = 0;
	saveDTS = 0;
	state = 0;
	timer = 0;
	saveSpherepos = 0;
	jmpLock = 0;
	timeToChange = 0;
	score = 0;
	stateScore = 0;
	animeColectable = 0;
	rotateBall = 0;
	isDangerCombustion = 0;
	lowCombustion = 0;

	{
		Mesh* mesh = new Mesh("box");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "box.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}


	{
		Mesh* mesh = new Mesh("CombustionMeter");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "screen_quad.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Mesh* mesh = new Mesh("CombustionScreen");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "screen_quad.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Mesh* mesh = new Mesh("sphere");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "sphere.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	projectionMatrix = glm::perspective(RADIANS(60), window->props.aspectRatio, 0.01f, 200.0f);

	const string textureLoc = "Source/Laboratoare/Tema3/Textures/";

	{
		Shader *shader = new Shader("Texture");
		shader->AddShader("Source/Laboratoare/Tema3/Shaders/VertexShader.glsl", GL_VERTEX_SHADER);
		shader->AddShader("Source/Laboratoare/Tema3/Shaders/FragmentShader.glsl", GL_FRAGMENT_SHADER);
		shader->CreateAndLink();
		shaders[shader->GetName()] = shader;
	}

	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "moon.jpg").c_str(), GL_REPEAT);
		mapTextures["MoonPlatform"] = texture;
	}

	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "greenPlatform.jpg").c_str(), GL_REPEAT);
		mapTextures["GreenPlatform"] = texture;
	}

	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "yellowPlatform.jpg").c_str(), GL_REPEAT);
		mapTextures["YellowPlatform"] = texture;
	}

	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "solar.png").c_str(), GL_REPEAT);
		mapTextures["OrangePlatform"] = texture;
	}

	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "lava.png").c_str(), GL_REPEAT);
		mapTextures["RedPlatform"] = texture;
	}

	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "moonSurface.jpg").c_str(), GL_REPEAT);
		mapTextures["Moon"] = texture;
	}

	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "fuel.jpg").c_str(), GL_REPEAT);
		mapTextures["Fuel"] = texture;
	}

	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "asteroid.jpg").c_str(), GL_REPEAT);
		mapTextures["Asteroid"] = texture;
	}

	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "space.jpg").c_str(), GL_REPEAT);
		mapTextures["Space"] = texture;
	}

	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "elegant-space.jpg").c_str(), GL_REPEAT);
		mapTextures["ElegantSpace"] = texture;
	}

	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "galaxy.png").c_str(), GL_REPEAT);
		mapTextures["Galaxy"] = texture;
	}

	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "AlienJuice.png").c_str(), GL_REPEAT);
		mapTextures["Alien"] = texture;
	}

	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "rocket.jpg").c_str(), GL_REPEAT);
		mapTextures["Rocket"] = texture;
	}

	glm::ivec2 resolution = window->GetResolution();

	Text = new TextRenderer(resolution.x, resolution.y);

	Text->Load("Source/TextRenderer/Fonts/Arial.ttf", 30);

	v = new int[3];

	for (int i = 0; i < 3; i++)
	{
		v[i] = rand() % 3;

	}

	if (v[0] == 0)
	{
		for (int i = 0; i < 25; i++)
		{
			for (int j = 0; j < 5; j++)
			{
				matGame[i][j] = saveMatGame[i][j];
			}
		}
	}
	else if (v[0] == 1)
	{
		for (int l = 0; l < 25; l++)
		{
			for (int c = 0; c < 5; c++)
			{
				matGame[l][c] = saveMatGame1[l][c];
			}
		}
	}
	else if (v[0] == 2)
	{
		for (int n = 0; n < 25; n++)
		{
			for (int m = 0; m < 5; m++)
			{
				matGame[n][m] = saveMatGame2[n][m];
			}
		}
	}
}

void StylisedRunner::FrameStart()
{
	glm::ivec2 resolution = window->props.resolution;

	// sets the clear color for the color buffer
	glClearColor(0, 0, 0, 1);

	// clears the color buffer (using the previously set color) and depth buffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}

void StylisedRunner::Update(float deltaTimeSeconds)
{
	moveSphere(xSphere, ySphere);

	speedPlatform += 1 * deltaTimeSeconds;

	rotateBall += 10 * deltaTimeSeconds;

	timeToChange = deltaTimeSeconds;

	saveDTS = deltaTimeSeconds;

	if (isColectable == 0)
	{
		animeColectable += 0.1 * deltaTimeSeconds;
		if (animeColectable >= 0.1)
		{
			isColectable = 1;
		}
	}
	else
	{
		animeColectable -= 0.1 * deltaTimeSeconds;
		if (animeColectable <= 0)
		{
			isColectable = 0;
		}
	}

	if (isDangerCombustion == 0)
	{
		lowCombustion += 0.01 * deltaTimeSeconds;
		if (lowCombustion >= 0.01)
		{
			isDangerCombustion = 1;
		}
	}
	else
	{
		lowCombustion -= 0.01 * deltaTimeSeconds;
		if (lowCombustion <= 0)
		{
			isDangerCombustion = 0;
		}
	}


	if (jmpLock == 1 && ySphere < 2)
	{
		ySphere += 3 * deltaTimeSeconds;
	}
	else if (jmpLock == 1 && ySphere >= 2)
	{
		jmpLock = 2;
		ySphere -= 3 * deltaTimeSeconds;
	}
	else if (jmpLock == 2)
	{
		if (ySphere == 0)
		{
			jmpLock = 0;
		}
		else
		{
			ySphere -= 3 * deltaTimeSeconds;
		}
	}

	combustion -= 100 * deltaTimeSeconds;

	if (stateCombustionGreen == 1)
	{
		rewardCombostion = 100;
		combustion += rewardCombostion;
		cout << "You have touched the green platform! You win :" << rewardCombostion << " combustion!" << endl;
		stateCombustionGreen = -1;
	}

	if (stateCombustionYellow == 1)
	{
		drainCombustion = 500;
		combustion -= drainCombustion;
		cout << "You have touched the yellow platform! You lose :" << drainCombustion << " combustion!" << endl;
		stateCombustionYellow = -1;
	}

	if (stateScore == 1)
	{
		score += 100;
		cout << "Score:" << score << endl;
		stateScore = -1;
	}

	if (stateRewardCombustion == 1)
	{
		rewardCombustionColectable = 500;
		score += 10;
		combustion += rewardCombustionColectable;
		cout << combustion << endl;
		stateRewardCombustion = -1;
	}

	if (combustion <= 0)
	{
		combustion = 0;
		cout << "You are out of fuel!" << endl;
		cout << "Combustion:" << combustion << endl;
		cout << "Score:" << score << endl;
		exit(0);
	}

	if (state == 1)
	{
		timer -= 2 * deltaTimeSeconds;
		platforms += 10 * deltaTimeSeconds;
		if (timer <= 0)
			state = 0;
	}


	if (xSphere < -3)
	{
		saveSpherepos = 0;
	}

	if (xSphere >= -3 && xSphere < -1)
	{
		saveSpherepos = 1;
	}

	if (xSphere >= -1 && xSphere < 1)
	{
		saveSpherepos = 2;
	}

	if (xSphere >= 1 && xSphere < 3)
	{
		saveSpherepos = 3;
	}

	if (xSphere >= 3)
	{
		saveSpherepos = 4;
	}


	for (int k = 0; k < 3; k++)
	{
		if (v[k] == 0)
		{
			for (int i = 0; i < 25; i++)
			{
				for (int j = 0; j < 5; j++)
				{
					glm::mat4 modelMatrix = glm::mat4(1);
					modelMatrix = glm::translate(modelMatrix, glm::vec3(j - 2, 0.10, -26 * k - i + platforms + speedPlatform));
					modelMatrix *= MyTransformer3DT3::Scale(1, 0.2, 1);

					glm::mat4 modelMatrixObstacle = glm::mat4(1);
					modelMatrixObstacle = glm::translate(modelMatrixObstacle, glm::vec3(j - 2, 0.5, -26 * k - i + platforms + speedPlatform));
					modelMatrixObstacle *= MyTransformer3DT3::Scale(1, 0.25, 1);

					if (matGame[i][j] == 1)
					{
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix, mapTextures["MoonPlatform"]);
					}
					else if (matGame[i][j] == 2)
					{
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix, mapTextures["GreenPlatform"]);
					}
					else if (matGame[i][j] == 3)
					{
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix, mapTextures["YellowPlatform"]);
					}
					else if (matGame[i][j] == 4)
					{
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix, mapTextures["RedPlatform"]);
					}
					else if (matGame[i][j] == 5)
					{
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix, mapTextures["OrangePlatform"]);
					}
					else if (matGame[i][j] == 6)
					{
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix, mapTextures["MoonPlatform"]);
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrixObstacle, mapTextures["Asteroid"]);
					}
					else if (matGame[i][j] == 7)
					{
						glm::mat4 ModelMatrixAlien = glm::mat4(1);
						ModelMatrixAlien = glm::translate(ModelMatrixAlien, glm::vec3(0, 0.5 + sin(animeColectable), -2 + speedPlatform + platforms));
						ModelMatrixAlien = glm::scale(ModelMatrixAlien, glm::vec3(0.50, 0.50, 0));
						RenderMeshTexture(meshes["box"], shaders["Texture"], ModelMatrixAlien, mapTextures["Alien"]);
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix, mapTextures["MoonPlatform"]);
					}
					else if (matGame[i][j] == 8)
					{
						glm::mat4 ModelMatrixRocket = glm::mat4(1);
						ModelMatrixRocket = glm::translate(ModelMatrixRocket, glm::vec3(0, 0.5 + sin(animeColectable), -4 + speedPlatform + platforms));
						ModelMatrixRocket = glm::scale(ModelMatrixRocket, glm::vec3(0.50, 0.50, 0));
						RenderMeshTexture(meshes["box"], shaders["Texture"], ModelMatrixRocket, mapTextures["Rocket"]);
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix, mapTextures["MoonPlatform"]);
					}
					else if (matGame[i][j] == 10)
					{
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix, mapTextures["Asteroid"]);
					}
				}
				if (i == (int)(ceil(platforms + speedPlatform)))
				{
					if ((matGame[i][saveSpherepos] == 0) && (ySphere == 0))
					{
						isFalling = true;
					}
					else if (matGame[i][saveSpherepos] == 1 && (ySphere == 0))
					{
						stateCombustionGreen = 0;
						stateCombustionYellow = 0;
						stateScore = 0;
						stateRewardCombustion = 0;
					}
					else if (matGame[i][saveSpherepos] == 2 && (ySphere == 0))
					{
						if (stateCombustionGreen != -1)
						{
							stateCombustionGreen = 1;
						}
						stateCombustionYellow = 0;
						stateScore = 0;
						stateRewardCombustion = 0;
					}
					else if (matGame[i][saveSpherepos] == 3 && (ySphere == 0))
					{
						stateCombustionGreen = 0;
						if (stateCombustionYellow != -1)
						{
							stateCombustionYellow = 1;
						}
						stateScore = 0;
						stateRewardCombustion = 0;
					}
					else if (matGame[i][saveSpherepos] == 4 && (ySphere == 0))
					{
						cout << "You have touched the red platform! Game over!" << endl;
						exit(0);
					}
					else if (matGame[i][saveSpherepos] == 5 && (ySphere == 0))
					{
						stateCombustionGreen = 0;
						stateCombustionYellow = 0;
						stateScore = 0;
						stateRewardCombustion = 0;
						state = 1;
						cout << "Your keybords W and S for movement platform are blocked for 5 seconds!" << endl;
						timer = 5;


					}
					else if (matGame[i][saveSpherepos] == 6 && (ySphere == 0))
					{
						cout << "You hit an obstacle!" << endl;
						exit(0);

					}
					else if (matGame[i][saveSpherepos] == 7 && (ySphere == 0))
					{
						stateCombustionGreen = 0;
						stateCombustionYellow = 0;
						if (stateScore != -1)
						{
							stateScore = 1;
						}
						stateRewardCombustion = 0;
					}
					else if (matGame[i][saveSpherepos] == 8 && (ySphere == 0))
					{
						stateCombustionGreen = 0;
						stateCombustionYellow = 0;
						stateScore = 0;
						if (stateRewardCombustion != -1)
						{
							stateRewardCombustion = 1;
						}
					}
					if (matGame[i][saveSpherepos] != 0 && (ySphere == 0))
					{
						matGame[i][saveSpherepos] = 10;
					}

				}
			}
		}
		else if (v[k] == 1)
		{
			for (int l = 0; l < 25; l++)
			{
				for (int c = 0; c < 5; c++)
				{
					glm::mat4 modelMatrix1 = glm::mat4(1);
					modelMatrix1 = glm::translate(modelMatrix1, glm::vec3(2 - c, 0.10, -26 * k - l + platforms + speedPlatform));
					modelMatrix1 *= MyTransformer3DT3::Scale(1, 0.2, 1);

					glm::mat4 modelMatrixObstacle1 = glm::mat4(1);
					modelMatrixObstacle1 = glm::translate(modelMatrixObstacle1, glm::vec3(c - 2, 0.5, -26 * k - l + platforms + speedPlatform));
					modelMatrixObstacle1 *= MyTransformer3DT3::Scale(1, 0.25, 1);

					if (matGame[l][c] == 1)
					{
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix1, mapTextures["MoonPlatform"]);
					}
					else if (matGame[l][c] == 2)
					{
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix1, mapTextures["GreenPlatform"]);
					}
					else if (matGame[l][c] == 3)
					{
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix1, mapTextures["YellowPlatform"]);
					}
					else if (matGame[l][c] == 5)
					{
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix1, mapTextures["OrangePlatform"]);
					}
					else if (matGame[l][c] == 6)
					{
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix1, mapTextures["MoonPlatform"]);
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrixObstacle1, mapTextures["Asteroid"]);
					}
					else if (matGame[l][c] == 7)
					{
						glm::mat4 ModelMatrixAlien = glm::mat4(1);
						ModelMatrixAlien = glm::translate(ModelMatrixAlien, glm::vec3(0, 0.5 + sin(animeColectable), -2 + speedPlatform + platforms));
						ModelMatrixAlien = glm::scale(ModelMatrixAlien, glm::vec3(0.50, 0.50, 0));
						RenderMeshTexture(meshes["box"], shaders["Texture"], ModelMatrixAlien, mapTextures["Alien"]);
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix1, mapTextures["MoonPlatform"]);
					}
					else if (matGame[l][c] == 8)
					{
						glm::mat4 ModelMatrixRocket = glm::mat4(1);
						ModelMatrixRocket = glm::translate(ModelMatrixRocket, glm::vec3(0, 0.5 + sin(animeColectable), -4 + speedPlatform + platforms));
						ModelMatrixRocket = glm::scale(ModelMatrixRocket, glm::vec3(0.50, 0.50, 0));
						RenderMeshTexture(meshes["box"], shaders["Texture"], ModelMatrixRocket, mapTextures["Rocket"]);
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix1, mapTextures["MoonPlatform"]);
					}
					else if (matGame[l][c] == 10)
					{
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix1, mapTextures["Asteroid"]);
					}

				}
				if (l == (int)(ceil(platforms + speedPlatform)))
				{
					if ((matGame[l][saveSpherepos] == 0) && (ySphere == 0))
					{
						isFalling = true;
					}
					else if (matGame[l][saveSpherepos] == 1 && (ySphere == 0))
					{
						stateCombustionGreen = 0;
						stateCombustionYellow = 0;
						stateScore = 0;
						stateRewardCombustion = 0;
					}
					else if (matGame[l][saveSpherepos] == 2 && (ySphere == 0))
					{
						if (stateCombustionGreen != -1)
						{
							stateCombustionGreen = 1;
						}

						stateCombustionYellow = 0;
						stateScore = 0;
						stateRewardCombustion = 0;
					}
					else if (matGame[l][saveSpherepos] == 3 && (ySphere == 0))
					{
						stateCombustionGreen = 0;
						if (stateCombustionYellow != -1)
						{
							stateCombustionYellow = 1;
						}
						stateScore = 0;
						stateRewardCombustion = 0;
					}
					else if (matGame[l][saveSpherepos] == 5 && (ySphere == 0))
					{
						stateCombustionGreen = 0;
						stateCombustionYellow = 0;
						stateScore = 0;
						stateRewardCombustion = 0;
						state = 1;
						timer = 5;
					}
					else if (matGame[l][saveSpherepos] == 6 && (ySphere == 0))
					{
						cout << "You hit an obstacle!" << endl;
						exit(0);

					}
					else if (matGame[l][saveSpherepos] == 7 && (ySphere == 0))
					{
						stateCombustionGreen = 0;
						stateCombustionYellow = 0;
						stateRewardCombustion = 0;
						if (stateScore != -1)
						{
							stateScore = 1;
						}
					}
					else if (matGame[l][saveSpherepos] == 8 && (ySphere == 0))
					{
						stateCombustionGreen = 0;
						stateCombustionYellow = 0;
						stateScore = 0;
						if (stateRewardCombustion != -1)
						{
							stateRewardCombustion = 1;
						}
					}
					if (matGame[l][saveSpherepos] != 0 && (ySphere == 0))
					{
						matGame[l][saveSpherepos] = 10;
					}
				}
			}
		}
		else if (v[k] == 2)
		{
			for (int n = 0; n < 25; n++)
			{
				for (int m = 0; m < 5; m++)
				{
					glm::mat4 modelMatrix2 = glm::mat4(1);
					modelMatrix2 = glm::translate(modelMatrix2, glm::vec3(m - 2, 0.10, -26 * k - n + platforms + speedPlatform));
					modelMatrix2 *= MyTransformer3DT3::Scale(1, 0.2, 1);

					if (matGame[n][m] == 1)
					{
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix2, mapTextures["MoonPlatform"]);
					}
					else if (matGame[n][m] == 2)
					{
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix2, mapTextures["GreenPlatform"]);
					}
					else if (matGame[n][m] == 3)
					{
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix2, mapTextures["YellowPlatform"]);
					}
					else if (matGame[n][m] == 4)
					{
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix2, mapTextures["RedPlatform"]);
					}
					else if (matGame[n][m] == 5)
					{
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix2, mapTextures["OrangePlatform"]);
					}
					else if (matGame[n][m] == 7)
					{
						glm::mat4 ModelMatrixAlien = glm::mat4(1);
						ModelMatrixAlien = glm::translate(ModelMatrixAlien, glm::vec3(0, 0.5 + sin(animeColectable), -2 + speedPlatform + platforms));
						ModelMatrixAlien = glm::scale(ModelMatrixAlien, glm::vec3(0.50, 0.50, 0));
						RenderMeshTexture(meshes["box"], shaders["Texture"], ModelMatrixAlien, mapTextures["Alien"]);
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix2, mapTextures["MoonPlatform"]);
					}
					else if (matGame[n][m] == 8)
					{
						glm::mat4 ModelMatrixRocket = glm::mat4(1);
						ModelMatrixRocket = glm::translate(ModelMatrixRocket, glm::vec3(0, 0.5 + sin(animeColectable), -4 + speedPlatform + platforms));
						ModelMatrixRocket = glm::scale(ModelMatrixRocket, glm::vec3(0.50, 0.50, 0));
						RenderMeshTexture(meshes["box"], shaders["Texture"], ModelMatrixRocket, mapTextures["Rocket"]);
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix2, mapTextures["MoonPlatform"]);
					}
					else if (matGame[n][m] == 10)
					{
						RenderMeshTexture(meshes["box"], shaders["Texture"], modelMatrix2, mapTextures["Asteroid"]);
					}
				}
				if (n == (int)(ceil(platforms + speedPlatform)))
				{
					if ((matGame[n][saveSpherepos] == 0) && (ySphere == 0))
					{
						isFalling = true;
					}
					else if (matGame[n][saveSpherepos] == 1 && (ySphere == 0))
					{
						stateCombustionGreen = 0;
						stateCombustionYellow = 0;
						stateScore = 0;
						stateRewardCombustion = 0;
					}
					else if (matGame[n][saveSpherepos] == 2 && (ySphere == 0))
					{
						if (stateCombustionGreen != -1)
						{
							stateCombustionGreen = 1;
						}

						stateCombustionYellow = 0;
						stateScore = 0;
						stateRewardCombustion = 0;
					}
					else if (matGame[n][saveSpherepos] == 3 && (ySphere == 0))
					{
						stateCombustionGreen = 0;
						if (stateCombustionYellow != -1)
						{
							stateCombustionYellow = 1;
						}
						stateScore = 0;
						stateRewardCombustion = 0;
					}
					else if (matGame[n][saveSpherepos] == 4 && (ySphere == 0))
					{
						cout << "You have touched the red platform! Game over!" << endl;
						exit(0);
					}
					else if (matGame[n][saveSpherepos] == 5 && (ySphere == 0))
					{
						stateCombustionGreen = 0;
						stateCombustionYellow = 0;
						stateScore = 0;
						stateRewardCombustion = 0;
						state = 1;
						cout << "Your keybords W and S for movement platform are blocked for 5 seconds!" << endl;
						timer = 5;

					}
					else if (matGame[n][saveSpherepos] == 6 && (heightPlatform1 >= ySphere))
					{
						cout << "You hit an obstacle!" << endl;
						exit(0);
					}
					else if (matGame[n][saveSpherepos] == 7 && (ySphere == 0))
					{
						stateCombustionGreen = 0;
						stateCombustionYellow = 0;
						stateRewardCombustion = 0;
						if (stateScore != -1)
						{
							stateScore = 1;
						}
					}
					else if (matGame[n][saveSpherepos] == 8 && (ySphere == 0))
					{
						stateCombustionGreen = 0;
						stateCombustionYellow = 0;
						stateScore = 0;
						if (stateRewardCombustion != -1)
						{
							stateRewardCombustion = 1;
						}
					}
					if (matGame[n][saveSpherepos] != 0 && (ySphere == 0))
					{
						matGame[n][saveSpherepos] = 10;
					}

				}

			}
		}
	}

	if (speedPlatform + platforms >= 26)
	{
		speedPlatform = 0;
		platforms = 0;
		shiftLeft();

		if (v[0] == 0)
		{
			for (int i = 0; i < 25; i++)
			{
				for (int j = 0; j < 5; j++)
				{
					matGame[i][j] = saveMatGame[i][j];
				}
			}
		}
		else if (v[0] == 1)
		{
			for (int l = 0; l < 25; l++)
			{
				for (int c = 0; c < 5; c++)
				{
					matGame[l][c] = saveMatGame1[l][c];
				}
			}
		}
		else if (v[0] == 2)
		{
			for (int n = 0; n < 25; n++)
			{
				for (int m = 0; m < 5; m++)
				{
					matGame[n][m] = saveMatGame2[n][m];
				}
			}
		}
	}

	if (combustion >= 10000)
		combustion = 10000;
	
	glm::mat4 ModelMatrix = glm::mat4(1);
	ModelMatrix = glm::translate(ModelMatrix, glm::vec3(0.30, 0.869, 0));
	ModelMatrix = glm::scale(ModelMatrix, glm::vec3(0.20, 0.1, 0.1));
	ModelMatrix = glm::translate(ModelMatrix, glm::vec3(combustion / 10000, 0, 0));
	ModelMatrix = glm::scale(ModelMatrix, glm::vec3(combustion / 10000, 1, 1));
	CombustionMesh(meshes["CombustionMeter"], shaders["Combustion"], ModelMatrix, glm::vec3(1, 0, 1));

	glm::mat4 ModelMatrix1 = glm::mat4(1);
	ModelMatrix1 = glm::translate(ModelMatrix1, glm::vec3(0.50, 0.869, 0));
	ModelMatrix1 = glm::scale(ModelMatrix1, glm::vec3(0.21, 0.11, 0.11));
	CombustionMesh(meshes["CombustionScreen"], shaders["Combustion"], ModelMatrix1, glm::vec3(1, 1, 1));

	if (combustion >= 1000)
	{
		glm::mat4 ModelMatrixFuel = glm::mat4(1);
		ModelMatrixFuel = glm::translate(ModelMatrixFuel, glm::vec3(0.30, 1.73, 0.5));
		ModelMatrixFuel = glm::scale(ModelMatrixFuel, glm::vec3(0.25, 0.25, 0));
		RenderMeshTexture(meshes["box"], shaders["Texture"], ModelMatrixFuel, mapTextures["Fuel"]);
	}


	if (combustion < 1000)
	{
		glm::mat4 ModelMatrixFuel = glm::mat4(1);
		ModelMatrixFuel = glm::translate(ModelMatrixFuel, glm::vec3(0.30, 1.73, 0.5 + sin(lowCombustion)));
		ModelMatrixFuel = glm::scale(ModelMatrixFuel, glm::vec3(0.25, 0.25, 0));
		RenderMeshTexture(meshes["box"], shaders["Texture"], ModelMatrixFuel, mapTextures["Fuel"]);
	}


	if (combustion > 8000)
	{
		glm::mat4 ModelMatrixBackGround = glm::mat4(1);
		ModelMatrixBackGround = glm::translate(ModelMatrixBackGround, glm::vec3(0.0, 0.0, 0.0));
		ModelMatrixBackGround = glm::scale(ModelMatrixBackGround, glm::vec3(300, 300, 280));
		RenderMeshTexture(meshes["box"], shaders["Texture"], ModelMatrixBackGround, mapTextures["Space"]);

		glm::mat4 ModelMatrixAsteroid = glm::mat4(1);
		ModelMatrixAsteroid = glm::translate(ModelMatrixAsteroid, glm::vec3(-1.45, 1.75, 0.4));
		ModelMatrixAsteroid = glm::scale(ModelMatrixAsteroid, glm::vec3(0.25, 0.15, 0.25));
		ModelMatrixAsteroid = glm::rotate(ModelMatrixAsteroid, RADIANS(-rotateBall * 180), glm::vec3(0, 1, 0));
		RenderMeshTexture(meshes["sphere"], shaders["Texture"], ModelMatrixAsteroid, mapTextures["Asteroid"]);
		changeOX = 0;
		changeOY = 1;
		changeOZ = 0;

	}
	else if (combustion > 5000)
	{
		glm::mat4 ModelMatrixBackGround1 = glm::mat4(1);
		ModelMatrixBackGround1 = glm::translate(ModelMatrixBackGround1, glm::vec3(0.0, 0.0, 0.0));
		ModelMatrixBackGround1 = glm::scale(ModelMatrixBackGround1, glm::vec3(300, 300, 280));
		RenderMeshTexture(meshes["box"], shaders["Texture"], ModelMatrixBackGround1, mapTextures["ElegantSpace"]);

		glm::mat4 ModelMatrixAsteroid = glm::mat4(1);
		ModelMatrixAsteroid = glm::translate(ModelMatrixAsteroid, glm::vec3(-1.45, 1.75, 0.4));
		ModelMatrixAsteroid = glm::scale(ModelMatrixAsteroid, glm::vec3(0.25, 0.15, 0.25));
		ModelMatrixAsteroid = glm::rotate(ModelMatrixAsteroid, RADIANS(-rotateBall * 180), glm::vec3(0, 1, 0));
		RenderMeshTexture(meshes["sphere"], shaders["Texture"], ModelMatrixAsteroid, mapTextures["Asteroid"]);

		glm::mat4 ModelMatrixAsteroid1 = glm::mat4(1);
		ModelMatrixAsteroid1 = glm::translate(ModelMatrixAsteroid1, glm::vec3(-1, 1.75, 0.4));
		ModelMatrixAsteroid1 = glm::scale(ModelMatrixAsteroid1, glm::vec3(0.25, 0.15, 0.25));
		ModelMatrixAsteroid1 = glm::rotate(ModelMatrixAsteroid1, RADIANS(-rotateBall * 180), glm::vec3(1, 0, 0));
		RenderMeshTexture(meshes["sphere"], shaders["Texture"], ModelMatrixAsteroid1, mapTextures["Asteroid"]);

		changeOX = 1;
		changeOY = 0;
		changeOZ = 0;

	}
	else if (combustion <= 5000)
	{
		glm::mat4 ModelMatrixBackGround2 = glm::mat4(1);
		ModelMatrixBackGround2 = glm::translate(ModelMatrixBackGround2, glm::vec3(0.0, 0.0, 0.0));
		ModelMatrixBackGround2 = glm::scale(ModelMatrixBackGround2, glm::vec3(300, 300, 280));
		RenderMeshTexture(meshes["box"], shaders["Texture"], ModelMatrixBackGround2, mapTextures["Galaxy"]);

		glm::mat4 ModelMatrixAsteroid = glm::mat4(1);
		ModelMatrixAsteroid = glm::translate(ModelMatrixAsteroid, glm::vec3(-1.45, 1.75, 0.4));
		ModelMatrixAsteroid = glm::scale(ModelMatrixAsteroid, glm::vec3(0.25, 0.15, 0.25));
		ModelMatrixAsteroid = glm::rotate(ModelMatrixAsteroid, RADIANS(-rotateBall * 180), glm::vec3(0, 1, 0));
		RenderMeshTexture(meshes["sphere"], shaders["Texture"], ModelMatrixAsteroid, mapTextures["Asteroid"]);

		glm::mat4 ModelMatrixAsteroid1 = glm::mat4(1);
		ModelMatrixAsteroid1 = glm::translate(ModelMatrixAsteroid1, glm::vec3(-1, 1.75, 0.4));
		ModelMatrixAsteroid1 = glm::scale(ModelMatrixAsteroid1, glm::vec3(0.25, 0.15, 0.25));
		ModelMatrixAsteroid1 = glm::rotate(ModelMatrixAsteroid1, RADIANS(-rotateBall * 180), glm::vec3(1, 0, 0));
		RenderMeshTexture(meshes["sphere"], shaders["Texture"], ModelMatrixAsteroid1, mapTextures["Asteroid"]);

		glm::mat4 ModelMatrixAsteroid2 = glm::mat4(1);
		ModelMatrixAsteroid2 = glm::translate(ModelMatrixAsteroid2, glm::vec3(-0.5, 1.75, 0.4));
		ModelMatrixAsteroid2 = glm::scale(ModelMatrixAsteroid2, glm::vec3(0.25, 0.15, 0.25));
		ModelMatrixAsteroid2 = glm::rotate(ModelMatrixAsteroid2, RADIANS(-rotateBall * 180), glm::vec3(0, 0, 1));
		RenderMeshTexture(meshes["sphere"], shaders["Texture"], ModelMatrixAsteroid2, mapTextures["Asteroid"]);

		changeOX = 0;
		changeOY = 0;
		changeOZ = 1;

	}


}

void StylisedRunner::drawHud()
{
	Text->RenderText("Score:" + to_string(score), 1110.0f, 20.0f, 1.0f, glm::vec3(0.0, 0.5, 0.0));
}

void StylisedRunner::FrameEnd()
{
	drawHud();
}

void StylisedRunner::RenderMeshTexture(Mesh * mesh, Shader * shader, const glm::mat4 & modelMatrix, Texture2D * texture1)
{
	if (!mesh || !shader || !shader->program)
		return;

	shader->Use();
	glUniformMatrix4fv(shader->loc_view_matrix, 1, GL_FALSE, glm::value_ptr(camera->GetViewMatrix()));
	glUniformMatrix4fv(shader->loc_projection_matrix, 1, GL_FALSE, glm::value_ptr(projectionMatrix));
	glUniformMatrix4fv(shader->loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

	if (texture1)
	{
		//TODO : activate texture location 0

		glActiveTexture(GL_TEXTURE0);

		//TODO : Bind the texture1 ID

		glBindTexture(GL_TEXTURE_2D, texture1->GetTextureID());

		//TODO : Send texture uniform value

		glUniform1i(glGetUniformLocation(shader->program, "texture_1"), 0);

	}

	glBindVertexArray(mesh->GetBuffers()->VAO);
	glDrawElements(mesh->GetDrawMode(), static_cast<int>(mesh->indices.size()), GL_UNSIGNED_SHORT, 0);



}

void StylisedRunner::RenderMesh(Mesh * mesh, Shader * shader, const glm::mat4 & modelMatrix)
{
	if (!mesh || !shader || !shader->program)
		return;

	shader->Use();
	glUniformMatrix4fv(shader->loc_view_matrix, 1, GL_FALSE, glm::value_ptr(camera->GetViewMatrix()));
	glUniformMatrix4fv(shader->loc_projection_matrix, 1, GL_FALSE, glm::value_ptr(projectionMatrix));
	glUniformMatrix4fv(shader->loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

	mesh->Render();
}

void StylisedRunner::RenderFromSphere(Mesh * mesh, Shader * shader, const glm::mat4 & modelMatrix, glm::vec3 color)
{
	if (!mesh || !shader || !shader->program)
		return;
	shader->Use();
	int pos = glGetUniformLocation(shader->program, "color");
	glUniform3fv(pos, 1, glm::value_ptr(color));

	int pos2 = glGetUniformLocation(shader->program, "changeTime");
	glUniform1f(pos2, timeToChange);

	glUniformMatrix4fv(shader->loc_view_matrix, 1, GL_FALSE, glm::value_ptr(camera->GetViewMatrix()));
	glUniformMatrix4fv(shader->loc_projection_matrix, 1, GL_FALSE, glm::value_ptr(projectionMatrix));
	glUniformMatrix4fv(shader->loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

	mesh->Render();
}


void StylisedRunner::CombustionMesh(Mesh * mesh, Shader * shader, const glm::mat4 & modelMatrix, glm::vec3 color)
{
	if (!mesh || !shader || !shader->program)
		return;

	shader->Use();

	int pos = glGetUniformLocation(shader->program, "color");
	glUniform3fv(pos, 1, glm::value_ptr(color));

	glUniformMatrix4fv(shader->loc_view_matrix, 1, GL_FALSE, glm::value_ptr(camera->GetViewMatrix()));
	glUniformMatrix4fv(shader->loc_projection_matrix, 1, GL_FALSE, glm::value_ptr(projectionMatrix));
	glUniformMatrix4fv(shader->loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

	mesh->Render();
}

void StylisedRunner::OnInputUpdate(float deltaTime, int mods)
{

	if (window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT))
	{
		float cameraSpeed = 2.0f;

		if (window->KeyHold(GLFW_KEY_W)) {
			// TODO : translate the camera forward
			camera->TranslateForward(deltaTime * cameraSpeed);
		}

		if (window->KeyHold(GLFW_KEY_A)) {
			// TODO : translate the camera to the left
			camera->TranslateRight(-deltaTime * cameraSpeed);
		}

		if (window->KeyHold(GLFW_KEY_S)) {
			// TODO : translate the camera backwards
			camera->TranslateForward(-deltaTime * cameraSpeed);
		}

		if (window->KeyHold(GLFW_KEY_D)) {
			// TODO : translate the camera to the right
			camera->TranslateRight(deltaTime * cameraSpeed);
		}

		if (window->KeyHold(GLFW_KEY_Q)) {
			// TODO : translate the camera down
			camera->TranslateUpword(-deltaTime * cameraSpeed);
		}

		if (window->KeyHold(GLFW_KEY_E)) {
			// TODO : translate the camera up
			camera->TranslateUpword(deltaTime * cameraSpeed);
		}
	}

	if ((window->KeyHold(GLFW_KEY_D)) && (!window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT)))
	{
		xSphere += 2 * deltaTime;
	}

	if (window->KeyHold(GLFW_KEY_A) && (!window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT)))
	{
		xSphere -= 2 * deltaTime;

	}

	if (window->KeyHold(GLFW_KEY_W) && (!window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT)) && state == 0 && isFalling == false)
	{
		platforms += 2 * deltaTime;
		combustion -= 10 * deltaTime;
	}

	if (window->KeyHold(GLFW_KEY_S) && (!window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT)) && state == 0 && isFalling == false)
	{
		platforms += 0.5 * deltaTime;
		combustion -= 10 * deltaTime;
	}


	if (window->KeyHold(GLFW_KEY_SPACE) && jmpLock == 0)
	{
		jmpLock = 1;
	}

}

void StylisedRunner::OnKeyPress(int key, int mods)
{
	if (key == GLFW_KEY_C)
	{
		camera->stateCamera();
	}
}

void StylisedRunner::OnKeyRelease(int key, int mods)
{

}

void StylisedRunner::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event
	if (window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT))
	{
		float sensivityOX = 0.001f;
		float sensivityOY = 0.001f;

		if (window->GetSpecialKeyState() == 0) {
			renderCameraTarget = false;
			// TODO : rotate the camera in First-person mode around OX and OY using deltaX and deltaY
			// use the sensitivity variables for setting up the rotation speed
			camera->RotateFirstPerson_OX(sensivityOX * -deltaY);
			camera->RotateFirstPerson_OY(sensivityOY * -deltaX);
		}

		if (window->GetSpecialKeyState() && GLFW_MOD_CONTROL) {
			renderCameraTarget = true;
			// TODO : rotate the camera in Third-person mode around OX and OY using deltaX and deltaY
			// use the sensitivity variables for setting up the rotation speed
			camera->RotateThirdPerson_OX(sensivityOX * -deltaY);
			camera->RotateThirdPerson_OY(sensivityOY * -deltaX);
		}

	}

}

void StylisedRunner::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void StylisedRunner::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void StylisedRunner::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void StylisedRunner::OnWindowResize(int width, int height)
{
}

void StylisedRunner::moveSphere(float x, float y)
{
	if (y > 3)
	{
		ySphere = 3;
	}

	if (isFalling == true)
	{
		ySphere -= 3 * saveDTS;

		if (isFalling == true && ySphere >= 0)
		{
			ySphere -= 3 * saveDTS;
		}

		if (isFalling == true && ySphere <= 0)
		{
			ySphere -= 3 * saveDTS;
		}

		if (ySphere < -3)
		{
			cout << "You have fallen from the platforms! Game over!" << endl;
			exit(0);
		}
	}


	if (isFalling == false)
	{
		if (y <= 0)
		{
			ySphere = 0;
		}
	}



	if (x < -4)
	{
		xSphere = -4;
	}

	if (x >= 4)
	{
		xSphere = 4;
	}

	glm::mat4 modelMatrix = glm::mat4(1);
	modelMatrix = glm::translate(modelMatrix, glm::vec3(0, 0.45, 0));
	modelMatrix = glm::scale(modelMatrix, glm::vec3(.5f));
	modelMatrix *= MyTransformer3DT3::Translate(x, y, 0);
	modelMatrix = glm::rotate(modelMatrix, RADIANS(-rotateBall * 45), glm::vec3(changeOX, changeOY, changeOZ));

	if (timer > 0)
	{
		RenderFromSphere(meshes["sphere"], shaders["FormSphere"], modelMatrix, glm::vec3(1, 0.5, 0));
	}
	else
	{
		//RenderMesh(meshes["sphere"], shaders["VertexNormal"], modelMatrix);
		RenderMeshTexture(meshes["sphere"], shaders["Texture"], modelMatrix, mapTextures["Moon"]);
	}

}

void StylisedRunner::shiftLeft()
{
	for (int i = 0; i < 2; i++)
	{
		v[i] = v[i + 1];
	}

	v[2] = rand() % 3;

}

StylisedRunner::~StylisedRunner()
{
	delete v;
}