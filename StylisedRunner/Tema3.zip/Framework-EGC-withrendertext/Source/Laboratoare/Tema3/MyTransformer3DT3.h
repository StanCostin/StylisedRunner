#pragma once

#include <include/glm.h>

namespace MyTransformer3DT3
{
	// Translate matrix
	inline glm::mat4 Translate(float tX, float tY, float tZ)
	{
		// TODO implement translate matrix
		return glm::transpose(glm::mat4(1, 0, 0, tX,
										0, 1, 0, tY,
										0, 0, 1, tZ,
										0, 0, 0,  1));
	}

	// Scale matrix
	inline glm::mat4 Scale(float sX, float sY, float sZ)
	{
		// TODO implement scale matrix
		return glm::mat4(sX, 0, 0, 0,
						 0, sY, 0, 0,
						 0, 0, sZ, 0,
						 0, 0, 0, 1);
	}

	// Rotate matrix relative to the OZ axis
	inline glm::mat4 RotateOZ(float u)
	{	

		// TODO implement rotate matrix
		return glm::transpose(glm::mat4(cos(u), -sin(u),  0,  0,
								        sin(u),  cos(u),  0,  0,
			                              0,	  0,	  1,  0,
								          0,      0,	  0,  1));
	}

	// Rotate matrix relative to the OY axis
	inline glm::mat4 RotateOY(float u)
	{
		// TODO implement rotate matrix
		return glm::transpose(glm::mat4(cos(u),  0,  sin(u),  0,
										  0,     1,    0,     0,
			                           -sin(u),  0,  cos(u),  0,
			                              0,     0,    0,     1));
	}

	// Rotate matrix relative to the OX axis
	inline glm::mat4 RotateOX(float u)
	{
		// TODO implement rotate matrix
		return glm::transpose(glm::mat4(1,    0,	   0,      0,
									    0,   cos(u), -sin(u),  0,
										0,   sin(u),  cos(u),  0,
									    0,     0,      0,      1));
	}
}
