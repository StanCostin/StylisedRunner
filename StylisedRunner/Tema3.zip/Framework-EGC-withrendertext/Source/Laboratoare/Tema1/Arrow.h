#pragma once
class Arrow {

private:



public:

	Arrow();
	~Arrow();

};