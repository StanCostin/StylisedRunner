#include "Objects2D.h"

#include <Core/Engine.h>

Mesh * Objects2D::CreateCircle(std::string name, glm::vec3 center, float radius, glm::vec3 color, bool fill)
{
	Mesh* mesh = new Mesh(name);
	glm::vec3 clr(color);
	std::vector<VertexFormat> vertices;
	std::vector<unsigned short> indices;

	vertices.push_back(VertexFormat(center));
	
	for (int i = 0; i <= 181; ++i) {
		glm::vec3 border_point(radius * cos((double)i * (M_PI)/(double) 180), radius * sin((double)i * M_PI /(double)180), 0);

		vertices.push_back(VertexFormat(center + border_point, clr));
		indices.push_back(i + 1);
	}

	if (!fill) {
		mesh->SetDrawMode(GL_LINE_STRIP);
	}
	else {
		
		//indices.push_back(0);
	}
	mesh->InitFromData(vertices, indices);
	return mesh;
}

Mesh * Objects2D::CreateBallons(std::string name, glm::vec3 center, float radius, glm::vec3 color, bool fill)
{
	Mesh* mesh = new Mesh(name);
	glm::vec3 clr(color);
	std::vector<VertexFormat> vertices;
	std::vector<unsigned short> indices;

	vertices.push_back(VertexFormat(center));

	for (int i = 0; i <= 360; ++i) {
		glm::vec3 border_point(radius * cos((double)i * (2 * M_PI) / (double)30), radius * sin((double)i * 2 * M_PI / (double)30), 0);

		vertices.push_back(VertexFormat(center + border_point, clr));
		indices.push_back(i + 1);
	}

	if (!fill) {
		mesh->SetDrawMode(GL_TRIANGLE_FAN);
	}
	else {

		//indices.push_back(0);
	}
	mesh->InitFromData(vertices, indices);
	return mesh;
}

Mesh* Objects2D::CreatePowerBarSize(std::string name, glm::vec3 leftBottomCorner, float length, glm::vec3 color, bool fill)
{
	glm::vec3 corner = leftBottomCorner;

	std::vector<VertexFormat> vertices =
	{
		VertexFormat(corner, color),
		VertexFormat(corner + glm::vec3(length, 0, 0), color),
		VertexFormat(corner + glm::vec3(length, length, 0), color),
		VertexFormat(corner + glm::vec3(0, length, 0), color)
	};

	Mesh* square = new Mesh(name);
	std::vector<unsigned short> indices = { 0, 1, 2, 3 };

	if (!fill) {
		square->SetDrawMode(GL_LINE_LOOP);
	}
	else {
		// draw 2 triangles. Add the remaining 2 indices
		indices.push_back(0);
		indices.push_back(2);
	}

	square->InitFromData(vertices, indices);
	return square;
}

